function validate(){
    if(document.querySelector('#id1') == "" )
    {
        alert('enter the username');
    }
    else if(document.querySelector('#id2') == "" )
    {
        alert('enter the correct password');
    }
    else if(document.querySelector('#id3') == "" )
    {
        alert('enter the emailId');
    }
    else{
        alert('fill up the information')
    }
}

function read(){
   let x = document.querySelector('#id1').value; 
  
   let z = document.querySelector('#id3').value; 
   x = document.appendChild(".refrenceid");
}

